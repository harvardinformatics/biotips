#!/bin/bash

bedtools intersect -c -a poeFor-windows-100k.bed -b data3/poeFor_NW_006799939.vcf 